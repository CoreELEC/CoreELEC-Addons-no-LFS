# SPDX-License-Identifier: GPL-2.0
# Copyright (C) 2024-present Team CoreELEC (https://coreelec.org)
